
/**
 * Write a description of class Nino here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Nino
{
    private int edad;
    private String medida;
    private double pesoNac;
    
    public Nino(int edad, String medida, double pesoNac){
        this.edad = edad;
        this.medida = medida;
        this.pesoNac = pesoNac;
    }
    public double getPesoNac(){
        return pesoNac;
    }
    public int edad(){
        return edad;
    }
    public boolean edadMeses(){
        return medida.equals("MESES");
    }
}

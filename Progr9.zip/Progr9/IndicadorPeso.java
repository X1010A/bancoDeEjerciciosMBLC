
/**
 * Write a description of class IndicadorPeso here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class IndicadorPeso
{
    public double calcularPeso(Nino nino){
        double pesoActual;
        pesoActual = nino.getPesoNac();
        if(nino.edadMeses()){
            pesoActual = pesoActual + calcularPesoMeses(nino);
        }else{
            pesoActual = 2*pesoActual + 5 * pesoActual/4; 
            pesoActual = pesoActual + calcularPesoAnios(nino);
        }
        return pesoActual;
    }
    
    private double calcularPesoMeses(Nino nino){
        double pesoAumento;
        double incremento;
        double y,x;
        x = nino.getPesoNac();
        y = 5*nino.getPesoNac()/4;
        if(nino.edad() <= 6){
            incremento = x/6;
            pesoAumento = incremento*nino.edad();
        }else{
            incremento = y/6;
            pesoAumento = x + (nino.edad()-6)*incremento;
        }
        return pesoAumento;
    }
    
    private double calcularPesoAnios(Nino nino){
        double pesoAumento;
        if(nino.edad()>1){
            pesoAumento = (nino.edad()-1) * 2.2;
        }else{
            pesoAumento = 0;
        }
        return pesoAumento;
    }
}

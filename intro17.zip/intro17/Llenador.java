
/**
 * Write a description of class Llenador here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Llenador{
    private int[][] matriz;
    public Llenador(int m, int n){
        matriz = new int[m][n];
    }
    public void llenarXFilas(){
        int dato;
        dato = 1;
        for(int fila = 0; fila < matriz.length; fila++){
            for(int col = 0; col < matriz[0].length; col++){
        	   matriz[fila][col] = dato++;
            }
        }
    }
    public void llenarXColumnas(){
        int dato;
        dato = 1;
        for(int col = 0; col < matriz[0].length; col++){
            for(int fila = 0; fila < matriz.length; fila++){
                matriz[fila][col] = dato++;
            }
        }
    }
    public String mostrar(){
        String reporte;
        reporte = "";
        for(int fila = 0; fila < matriz.length; fila++){
            for(int col = 0; col < matriz[0].length; col++){
        	   reporte += matriz[fila][col] + "\t";
            }
            reporte += "\n";
        }
        return reporte;
    }
}

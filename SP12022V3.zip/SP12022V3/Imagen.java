import java.util.ArrayList;
/**
 * Write a description of class Imagen here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Imagen
{
    private int[][] foto;
    private boolean[][] copia;
    private int m,n;
    
    public Imagen(int[][] foto){
        this.foto = foto;
        m = foto.length;
        n = foto[0].length; 
    }
    
    // inciso d
    public ArrayList<Coordenada> buscar(Depredador dep){
        ArrayList<Coordenada> coordenadas;
        int tamanio;
        coordenadas = new ArrayList<Coordenada>();
        copia = new boolean[m][n]; // por defecto todas las celdas estan en false
                                   // esto significa que ninguna celda de la imagen
                                   // ha sido usada identificando una huella
        tamanio = dep.getTamano();
        for(int i = 0; i < m - tamanio + 1; i++){
            for(int j = 0; j < n - tamanio + 1; j++){
                if(!copia[i][j]){ // si la celda no es parte de un emparejamiento
                    if(dep.huellaIgual(obtenerArea(i,j,tamanio))){
                        coordenadas.add(new Coordenada(i,j));
                        marcarArea(i, j, tamanio);
                    }
                }
            }
        }
        return coordenadas;
    }
        
    // marca el area donde se ha encontrado una huella
    private void marcarArea(int i, int j, int tamanio){
        for(int fil = 0; fil < tamanio; fil++){
            for(int col = 0; col < tamanio; col++){
                copia[i+fil][j+col] = true; //se marca la celda para indicar que
                                            //ese pixel ya se ha considerado
                                            //en el emparejamiento de una huella
            }
        }
    }
    // se genera una subimagen de la imagen
    // que equivale al tamanio de una huella
    private int[][] obtenerArea(int i, int j, int tamanio){
        int[][] area = new int[tamanio][tamanio];
        for(int fil = 0; fil < tamanio; fil ++){
            for(int col = 0; col < tamanio; col++){
                area[fil][col] = foto[i+fil][j+col];
            }
        }
        return area;
    }
}


/**
 * Write a description of class Jugada here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Jugada
{
    private String nombre;
    
    public Jugada(String nombre){
        this.nombre = nombre;
    }
    
    public boolean esMejor(Jugada otra){
        boolean esMejor;
        esMejor = false;
        if(nombre == "Piedra" && otra.getNombre() == "Tijeras"){
            esMejor = true;
        }else{
            if(nombre == "Papel" && otra.getNombre() == "Piedra"){
                esMejor = true;
            }else{
                if(nombre == "Tijeras" && otra.getNombre() == "Papel"){
                    esMejor = true;
                }
            }
        }
        return esMejor;
    }
    
    public String getNombre(){
        return nombre;
    }
}

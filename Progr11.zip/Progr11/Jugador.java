
/**
 * Write a description of class Jugador here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Jugador
{
    private String nombre;
    private int puntaje;
    
    public Jugador(String nombre){
        this.nombre = nombre;
        puntaje     = 0;
    }
    
    public boolean mejor(Jugador otro){
        return puntaje > otro.getPuntaje();
    }
    
    public int getPuntaje(){
        return puntaje;
    }
    
    public void aumentarPts(){
        puntaje++;
    }
    
    public Jugada jugar(){
        Jugada jugada;
        int opc = (int)(Math.random()*3);
        switch(opc){
            case 0 : jugada = new Jugada("Piedra");break;
            case 1 : jugada = new Jugada("Papel"); break;
            default : jugada = new Jugada("Tijeras");
        }
        return jugada;
    }
}

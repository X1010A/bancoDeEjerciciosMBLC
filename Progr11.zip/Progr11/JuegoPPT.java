
/**
 * Write a description of class JuegoPPT here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class JuegoPPT
{
    private int nroPartidas;
    private Jugador jug1;
    private Jugador jug2;
    
    public JuegoPPT(int nroPartidas, Jugador jug1, Jugador jug2){
        this.nroPartidas = nroPartidas;
        this.jug1        = jug1;
        this.jug2        = jug2;
    }
    
    public Jugador jugar(){
        Jugador ganador;
        int i;
        for(i = 1; i <= nroPartidas; i = i + 1){
            partida();
        }
        if(jug1.mejor(jug2)){
            ganador = jug1;
        }else{
            if(jug2.mejor(jug1)){
                ganador = jug2;
            }else{
                ganador = null;
            }
        }
        return ganador;
    }
    
    private void partida(){
        Jugada jugada1;
        Jugada jugada2;
        jugada1 = jug1.jugar();
        jugada2 = jug2.jugar();
        if(jugada1.esMejor(jugada2)){
            jug1.aumentarPts();
        }else{
            if(jugada2.esMejor(jugada1)){
                jug2.aumentarPts();
            }
        }
    }
}

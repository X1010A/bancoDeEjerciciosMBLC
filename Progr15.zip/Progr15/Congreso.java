
/**
 * Write a description of class Congreso here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Congreso
{
    private String palNegra;
    
    public Congreso(String palNegra){
        this.palNegra = palNegra;
    }
    
    public boolean verificar(Bruja bruja){
        boolean esMagiaNegra;
        String conjuro;
        int letraPal, letraConj;
        conjuro   = bruja.getConjuro();
        letraPal  = 0;
        letraConj = 0;
        palNegra  = palNegra.toLowerCase();
        conjuro   = conjuro.toLowerCase();
        while(letraPal < palNegra.length() && letraConj < conjuro.length()){
            if(palNegra.charAt(letraPal) == conjuro.charAt(letraConj)){
                letraPal++;
                letraConj++;
            }else{
                letraConj++;
            }
        }
        esMagiaNegra = letraPal == palNegra.length();
        return esMagiaNegra;
    }
}

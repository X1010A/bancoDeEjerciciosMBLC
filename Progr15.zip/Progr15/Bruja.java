
/**
 * Write a description of class Bruja here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Bruja
{
    private String nombre;
    private String conjuro;
    
    public Bruja(String nombre, String conjuro){
        this.nombre  = nombre;
        this.conjuro = conjuro;
    }
    
    public String getConjuro(){
        return conjuro;
    }
}

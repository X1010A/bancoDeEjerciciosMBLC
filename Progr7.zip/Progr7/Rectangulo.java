
/**
 * Write a description of class Rectangulo here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Rectangulo
{
    private Punto esquinaSupIzq;
    private Punto esquinaInfDer;
    /**
     * @param aesquinaSupIzq representa a la esquina superior izquierda
     */
    public Rectangulo(Punto esquinaSupIzq, Punto esquinaInfDer){
        this.esquinaSupIzq = esquinaSupIzq;
        this.esquinaInfDer = esquinaInfDer;
    }
    public double getBase(){
        return esquinaSupIzq.distanciaX(esquinaInfDer);
    }
}


/**
 * Write a description of class Punto here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Punto
{
    private int coordX;
    private int coordY;
    
    public Punto(int coordX, int coordY){
        this.coordX = coordX;
        this.coordY = coordY;
    }
    
    public double distanciaX(Punto otro){
        return Math.abs(coordX - otro.getX());
    }
    public int getX(){
        return coordX;
    }
}

import java.util.ArrayList;
/**
 * Write a description of class Paralelo here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Paralelo
{
    private String nominacion;
    private ArrayList<Estudiante> estudiantes;
    
    public Paralelo(String nom){
        nominacion = nom;
        estudiantes = new ArrayList<Estudiante>();
    }
    
}


/**
 * Write a description of class Recuerdo here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Recuerdo
{
    private String titulo;
    private String descripcion;
    private String tipo;
    private String adicional;
    
    public Recuerdo(String tit, String desc, String tipo, String adic){
        titulo = tit;
        descripcion = desc;
        this.tipo = tipo;
        adicional = adic;
    }
    
    public Recuerdo(String tit, String desc, String tipo){
        titulo = tit;
        descripcion = desc;
        this.tipo = tipo;
        adicional = "";
    }
}

import java.util.ArrayList;

/**
 * Write a description of class Anuario here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Anuario
{
    private ArrayList<Grado> grados;
    
    public Anuario(){
        grados = new ArrayList<Grado>();
    }
    
    public boolean ingresar(String nombreEst, Recuerdo rec){
        return false;
    }
    
    public String reporteRecuerdos(String nombreEst){
        return "";
    }
    
    public boolean verficarMismoPar(String x, String y){
        return false;
    }
    
    public ArrayList<Estudiante> obtenerEstSinRec(){
        return null;
    }
}

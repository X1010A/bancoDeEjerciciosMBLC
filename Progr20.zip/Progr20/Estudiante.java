import java.util.ArrayList;

/**
 * Write a description of class Estudiante here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Estudiante
{
    private String nombre;
    private ArrayList<Recuerdo> recuerdos;
    
    public Estudiante(String nom){
        nombre = nom;
        recuerdos = new ArrayList<Recuerdo>();
    }
}

import java.util.ArrayList;

/**
 * Write a description of class Grado here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Grado
{
    private ArrayList<Paralelo> paralelos;
    
    public Grado(){
        paralelos = new ArrayList<Paralelo>();
    }
    
}

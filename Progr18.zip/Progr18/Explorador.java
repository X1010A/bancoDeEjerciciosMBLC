import java.util.ArrayList;

/**
 * Write a description of class Explorador here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Explorador
{
    private boolean[] criba;
    public ArrayList<Integer> encontrarPrimosMen(int n){
        ArrayList<Integer> primos;
        int lim;
        int v;
        
        primos = new ArrayList<Integer>();//{}
        
        // primer
        inicializarCriba(n);
        // segundo
        lim = (int)Math.sqrt(n);
        // tercer
        for(v = 2; v <= lim; v++){
            if(criba[v]){
                primos.add(v);
                tacharMultiplos(v);
            }
        }
        // cuarto
        recogerPrimos(v, primos);
        // quinto
        return primos;
    }
    
    private void inicializarCriba(int n){
        criba = new boolean[n+1];
        for(int celda = 2; celda <= n; celda++){
            criba[celda] = true;
        }
    }
    
    private void tacharMultiplos(int v){
        for(int celda = v; celda < criba.length; celda = celda + v){
            criba[celda] = false;
        }
    }
    
    private void recogerPrimos(int v, ArrayList<Integer> primos){
        for(int celda = v; celda < criba.length; celda++){
            if(criba[celda]){
                primos.add(celda);
            } 
        }
    }
}

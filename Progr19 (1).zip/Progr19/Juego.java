
/**
 * Write a description of class Juego here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Juego
{
    private int nivel;
    private int[][] grilla;
    private boolean estado;
    private boolean cambio;
    
    public Juego(int nivel){
        this.nivel = nivel;
        inicializar();
    }
    
    public void inicializar(){
        grilla = new int[4][4];
        estado = true;
        cambio = false;
    }
    
    public void moverDer(){
        if(estado){
            for(int f = 0; f < 4; f++){
                moverFilaDer(f);
            }
        }
    }
    
    private void moverFilaDer(int f){
        int c, c1;
        boolean termino;
        c = 3;
        termino = false;
        while(c >= 0 && !termino){
            if(grilla[f][c] == 0){
                c1 = buscar(f, c-1);
                if(c1 == -1){
                  termino = true;
                }else{ 
                   cambio = true;
                   grilla[f][c] = grilla[f][c1];
                   grilla[f][c1] = 0;
                }
            }else{
               c1 = buscar(f, c-1);
               if(c1 == -1){
                   termino = true;
               }else{
                   if(grilla[f][c] == grilla[f][c1]){
                       cambio = true;
                       grilla[f][c] = grilla[f][c] + grilla[f][c1];
                       grilla[f][c1] = 0;
                       c = c-1;
                   }else{ 
                       grilla[f][c-1] = grilla[f][c1];
                       if(c-1 != c1){
                           cambio = true;
                           grilla[f][c1] = 0;
                       }
                       c = c-1;
                   }
               }
            }  
        }
    }
    
    private int buscar(int f, int col){
        int c1;
        boolean encontre = false;
        c1 = -1;
        while(col >= 0 && !encontre){
            if(grilla[f][col] != 0){
                encontre = true;
                c1 = col;
            }
            col --;
        }
        return c1;
    }
    
}
    


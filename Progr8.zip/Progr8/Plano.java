
/**
 * Write a description of class Plano here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Plano
{
    private Posicion esqSup;
    private Posicion esqInf;
    
    public Plano(Posicion esqSup, Posicion esqInf){
        this.esqSup = esqSup;
        this.esqInf = esqInf;
    }
    
    public boolean estaEn(Posicion posicion){
        return esqSup.getX() <= posicion.getX() &&
               posicion.getX() <= esqInf.getX() &&
               esqInf.getY() <= posicion.getY() &&
               posicion.getY() <= esqSup.getY();
    }
}

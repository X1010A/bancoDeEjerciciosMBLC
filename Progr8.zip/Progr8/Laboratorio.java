
/**
 * Write a description of class Laboratorio here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Laboratorio
{
    private Robot robot;
    private Plano plano;
    
    public Laboratorio(Plano plano, Robot robot){
        this.plano = plano;
        this.robot = robot;
    }
    
    public String avanzar(){
        return robot.avanzar(plano);
    }
    
    public void girar(){
        robot.girar();
    }
    
    public int getMemoria(){
        return robot.getMemoria();
    }
}


/**
 * Write a description of class Posicion here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Posicion
{
    private int x;
    private int y;
    
    public Posicion(int x, int y){
        this.x = x;
        this.y = y;
    }
    
    public Posicion generarPos(char direccion){
        Posicion nuevaPosicion;
        int nuevoX, nuevoY;
        nuevoX = x;
        nuevoY = y;
        switch(direccion){
            case 'N': nuevoY = y+1;
                      break;
            case 'O': nuevoX = x-1;
                      break;
            case 'S': nuevoY = y-1;
                      break;
            case 'E': nuevoX = x+1;
                      break;          
        }
        nuevaPosicion = new Posicion(nuevoX, nuevoY);
        return nuevaPosicion;
    }
    
    public int getX(){
        return x;
    }
    
    public int getY(){
        return y;
    }
}

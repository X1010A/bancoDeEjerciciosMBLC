
/**
 * Write a description of class Robot here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Robot
{
    private Posicion posicion;
    private boolean perdido;
    private int memoria;
    private char direccion;
    
    public Robot(Posicion posicion){
        this.posicion = posicion;
        perdido = false;
        memoria = verificar();
        direccion = 'N';
    }
    /**
     * suma los valores de la posicion actual del robot
     * si la suma es mutliplo de 2 o 3 devuelve la suma, caso
     * contrario devuelve 0
     */
    private int verificar(){
        int suma;
        suma = posicion.getX() + posicion.getY();
        if((suma % 2) != 0 && (suma%3) != 0){
            suma = 0;
        }
        return suma;
    }
    
    public String avanzar(Plano plano){
        String reporte;
        if(perdido){
            reporte = "Robot perdido";
        }else{
            posicion = posicion.generarPos(direccion);
            if(plano.estaEn(posicion)){
                reporte = "Explorando..";
                memoria = memoria + verificar();
            }else{
                reporte = "Robot perdido";
                perdido = true;
            }
        }
        return reporte;
    }
    
    public void girar(){
        if(!perdido){
            switch(direccion){
               case 'N': direccion = 'O'; break;
               case 'E': direccion = 'N'; break;
               case 'S': direccion = 'E'; break;
               case 'O': direccion = 'S';
            }
        }
    }
    
    public int getMemoria(){
        return memoria;
    }
}

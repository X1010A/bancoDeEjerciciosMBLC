
/**
 * Write a description of class Juego here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Juego
{
    private int nivel;
    private int[][] grilla;
    private boolean estado;
    private boolean cambio;
    private String msj;
    private boolean ganaste;
    private boolean perdiste;
    
    public Juego(int nivel){
        this.nivel = nivel;
        inicializar();
    }
    
    public void inicializar(){
        grilla = new int[4][4];
        estado = true;
        cambio = false;
        msj = "Realiza movimiento";
        ganaste = false;
        perdiste = false;
        ubicarNum();
        ubicarNum();
        mostrar();
    }
    
    public void moverDer(){
        if(estado){
            cambio = false;
            for(int f = 0; f < 4; f++){
                moverFila(f, 3, -1, -1);
            }
            actualizarEstado();
            mostrar();
        }else{
            msj = "juego terminado. inicializa";
            mostrar();
        }
    }
    
    public void moverIzq(){
        if(estado){
            cambio = false;
            for(int f = 0; f < 4; f++){
                moverFila(f, 0, 4, 1);
            }
            actualizarEstado();
            mostrar();
        }else{
            msj = "juego terminado. inicializa";
            mostrar();
        }
    }
    
    public void moverArr(){
    }
    
    public void moverAba(){
    }
    
    private void actualizarEstado(){
        if(cambio){
            if(ganaste){
                msj = "Ganaste,juego terminado";
                estado = false;
            }else{
                ubicarNum();
                if(perdiste){
                    msj = "Perdiste,juego terminado";
                    estado = false;
                }else{
                    msj = "Realiza movimiento";
                }
            }
        }else{
            msj = "No cambio. Realiza movimiento";
        }
    }
    
    private void moverFila(int f, int ini, int lim, int incr){
        int c, c1;
        boolean termino;
        c = ini;
        termino = false;
        while(c != lim && !termino){
            if(grilla[f][c] == 0){
                c1 = buscar(f, c + incr, lim, incr);
                if(c1 == -1){
                  termino = true;
                }else{ 
                   cambio = true;
                   grilla[f][c] = grilla[f][c1];
                   grilla[f][c1] = 0;
                }
            }else{
               c1 = buscar(f, c + incr, lim, incr);
               if(c1 == -1){
                   termino = true;
               }else{
                   if(grilla[f][c] == grilla[f][c1]){
                       cambio = true;
                       grilla[f][c] = grilla[f][c] + grilla[f][c1];
                       grilla[f][c1] = 0;
                       c = c + incr;
                       if(grilla[f][c] == nivel)
                          ganaste = true;
                   }else{ 
                       grilla[f][c+incr] = grilla[f][c1];
                       if(c+incr != c1){
                           cambio = true;
                           grilla[f][c1] = 0;
                       }
                       c = c+incr;
                   }
               }
            }  
        }
    }
    
    private int buscar(int f, int col, int lim, int incr){
        int c1;
        boolean encontre = false;
        c1 = -1;
        while(col != lim && !encontre){
            if(grilla[f][col] != 0){
                encontre = true;
                c1 = col;
            }
            col = col + incr;
        }
        return c1;
    }
    
    public void ubicarNum(){
        int numero = (int)(Math.random()*2) == 0 ? 2: 4;
        int f, c;
        
        do{
            f =(int)(Math.random()*4);
            c =(int)(Math.random()*4);
        }while(grilla[f][c] != 0);
        
        grilla[f][c] = numero;
        sePuedeMover();
    }
    public void sePuedeMover(){
        int f, c;
        boolean sePuede = false;
        f = 0; c = 0;
        while(f < 4 && c < 4 && !sePuede){
            if(grilla[f][c] == 0){
                sePuede = true;
            }
            if(c+1 < 4 && grilla[f][c] == grilla[f][c+1]){
                sePuede = true;
            }
            if(f+1 < 4 && grilla[f][c] == grilla[f+1][c]){
                sePuede = true;
            }
            if(c == 3){
                c = 0;
                f ++;
            }else{
                c++;
            }
        }
        if(!sePuede){
            perdiste = true;
        }
    }
    
    public void mostrar(){
        for(int f = 0; f < 4; f++){
            for(int c = 0; c < 4 ; c++){
                System.out.print("\t"+ (grilla[f][c] == 0? "_":grilla[f][c]));
            }
            System.out.println();
        }
        System.out.println(msj);
    }
}
    



/**
 * Write a description of class CuentaBancaria here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class CuentaBancaria
{
    private String titular;
    private int nroCuenta;
    private double saldo;
    private String moneda;
    private int ci;
    public CuentaBancaria(String titular, int ci, String moneda ){
        this.titular = titular;
        this.ci      = ci;
        this.moneda  = moneda;
        saldo        = 0.0;
        nroCuenta    = (int)(Math.random()*1000 + 100);
    }
    /**
     * monto debe ser mayor a 0
     *   ? : 
     *  cond ? val1 : val2   genera uno de dos valores de acuerdo a una condicion
     *  si condicion es verddera entonces se devuelve val1, caso contrario se delvuelve val2
     */
    public double retirar(double monto){
        double montoRetirado;
        montoRetirado = (monto <= saldo)? monto : 0;
        saldo = saldo - montoRetirado;
        return montoRetirado;
    }
    /**
     * monto debe ser mayor a 0
     */
    public void depositar(double monto){
        saldo = saldo + monto;
    }
}


    


/**
 * Write a description of class Triangulo here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Triangulo
{
    // atributos --- propiedades atribuibles
    int lado1;
    int lado2;
    int lado3;
    
    // metodos   --- responsabilidades funcionales
    int getLado1(){
        return lado1;
    }
    
    void setLado1(int l1){
        lado1 = l1;
    }
    
    void setLado2(int l2){
        lado2 = l2;
    }
    
    void setLado3(int l3){
        lado3 = l3;
    }
    
    double calcularPerimetro(){
        double perimetro;
        perimetro = lado1 + lado2 + lado3;
        return perimetro;
    }
}



import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
/**
 * The test class AnalizadorTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class AnalizadorTest
{
    /**
     * Default constructor for test class AnalizadorTest
     */
    public AnalizadorTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp()
    {
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @AfterEach
    public void tearDown()
    {
    }
    
    @Test
    public void test1(){
        ArrayList<Palabra> palabras;
        Analizador analizador;
        palabras = new ArrayList<Palabra>();
        palabras.add(new Palabra("hola", 4));
        palabras.add(new Palabra("cruel", 16));
        palabras.add(new Palabra("mundo", 10));
        System.out.println(palabras.toString());
        analizador = new Analizador();
        System.out.println(analizador.obtenerDiscurso(palabras));
    }
    
    @Test
    public void test2(){
        ArrayList<Palabra> palabras;
        Analizador analizador;
        palabras = new ArrayList<Palabra>();
        palabras.add(new Palabra("el", 16));
        palabras.add(new Palabra("auditorio", 45));
        palabras.add(new Palabra("el", 35));
        palabras.add(new Palabra("final", 29));
        palabras.add(new Palabra("dando", 13));
        System.out.println(palabras.toString());
        analizador = new Analizador();
        System.out.println(analizador.obtenerDiscurso(palabras));
    }
    
    
    @Test
    public void test5(){
        ArrayList<Palabra> palabras;
        Analizador analizador;
        palabras = new ArrayList<Palabra>();
        palabras.add(new Palabra("aqui", 4));
        palabras.add(new Palabra("hay", 5));
        palabras.add(new Palabra("error", 17));
        System.out.println(palabras.toString());
        analizador = new Analizador();
        System.out.println(analizador.obtenerDiscurso(palabras));
    }
    @Test
    public void test3(){
        ArrayList<Palabra> palabras;
        Analizador analizador;
        analizador = new Analizador();
        System.out.println(analizador.deletrear("este es un discurso largo muy largo pero es buen ejemplo"));
    }
    
    @Test
    public void test4(){
        ArrayList<Palabra> palabras;
        Analizador analizador;
        analizador = new Analizador();
        System.out.println(analizador.deletrear("aqui hay un error"));
    }
    
    
    
}

import java.util.ArrayList;
/**
 * Write a description of class Analizador here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Analizador
{
    private String[] palabrasOrd;
    public Analizador(){
    }
    
    public String obtenerDiscurso(ArrayList<Palabra> palabras){
        String discurso;
        palabrasOrd = new String[1001];
        for(Palabra pal: palabras){
            palabrasOrd[pal.getTiempo()] = pal.getPalabra();
        }
        discurso = construir();
        return discurso;
    }
    
    private String construir(){
        String discurso, pal;
        boolean error;
        int posIni, dif;
        posIni = 0;
        discurso = "";
        error = false;
        for(int i = 1; i < palabrasOrd.length && !error; i++){
            pal = palabrasOrd[i];
            if(pal != null){
                dif = i - pal.length();
                if(posIni == dif){
                    discurso = discurso + pal + " ";
                    posIni = i + 1;
                }else{
                    if(dif > posIni){
                        discurso = discurso + "- " + pal + " "; 
                        posIni = i + 1;
                    }else{
                        discurso = "ERROR";
                        error = true;
                    }
                }
            }
        }
        return discurso;
    }
    
    public ArrayList<Palabra> deletrear(String discurso){
        ArrayList<Palabra> deletreo;
        int tiempo;
        String[] pals = discurso.split(" ");
        tiempo = 0;
        deletreo = new ArrayList<Palabra>();
        for(String pal: pals){
            deletreo.add(new Palabra(pal, tiempo + pal.length()));
            tiempo = tiempo + pal.length() + 1;
        }
        return deletreo;
    }
}

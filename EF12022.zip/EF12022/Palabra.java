
/**
 * Write a description of class Palabra here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Palabra
{
    private String palabra;
    private int tiempo;
    
    public Palabra(String palabra, int tiempo){
        this.palabra = palabra;
        this.tiempo = tiempo;
    }
    
    public int inicio(){
        return tiempo - palabra.length();
    }
    
    public int getTiempo(){
        return tiempo;
    }
    
    public String getPalabra(){
        return palabra;
    }
    
    public String toString(){
        return "(" + palabra + ", " + tiempo + ")";
    }
}

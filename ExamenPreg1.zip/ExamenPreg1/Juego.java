
/**
 * Write a description of class Juego here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Juego
{
    private int numeroObjetivo;
    private int valorAcumulado;
    private int turno; // 0 humano 1 computadora
    private boolean enJuego; // 
    
    public Juego(){
        inicializar();
    }
    
    private void inicializar(){
        numeroObjetivo = (int)(Math.random()*50 + 10);
        valorAcumulado = 0;
        turno = 0;
        enJuego = true;
    }
    public String jugar(int incremento){
        String reporte = "";
        return reporte;
    }
}
    


/**
 * Write a description of class Juego here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Juego
{
    private Palabra[] palabras;
    private Palabra palSecreta;
    private boolean enJuego;
    private int nroErrores;
    
    public Juego(Palabra[] palabras){
        this.palabras = palabras;
        palSecreta    = null;
        enJuego       = false;
        nroErrores    = 0;
    }
    
    public String inicializar(){
        String reporteInicial;
        int pos;
        pos = (int)(Math.random()*palabras.length);
        palSecreta = palabras[pos];
        enJuego    = true;
        nroErrores = 0;
        reporteInicial = palSecreta.getDescripcion() + "\n";
        reporteInicial = reporteInicial + palSecreta.mostrarLetras();
        reporteInicial = reporteInicial + "\n Ingresa una letra";
        return reporteInicial;
    }
    
    public String jugar(char letra){
        String reporte;
        if(enJuego){
            if(palSecreta.existe(letra)){
                if(palSecreta.completa()){
                    reporte = reporteFinal("Ganaste");
                }else{
                    reporte = generarReporte();
                    reporte = reporte + "\n Ingresa una letra";
                }
            }else{
                nroErrores++;
                if(nroErrores == 6){
                    reporte = generarReporte();
                    reporte = reporte + reporteFinal("Perdiste");
                }else{
                    reporte = "Error!! \n" + generarReporte();
                    reporte = reporte + "\n Ingresa una letra";
                }
            }
        }else{
            reporte = "Inicializa el juego";
        }
        return reporte;
    }
    
    private String reporteFinal(String estado){
        String reporte;
        reporte = estado +", la palabra secreta es:";
        reporte = reporte + palSecreta.getConcepto();
        enJuego = false;
        palSecreta.inicializar();
        return reporte;
    }
    private String generarReporte(){
        String estadoActual;
        estadoActual = palSecreta.mostrarLetras() + "\n";
        estadoActual = estadoActual + dibujarCuerpo();
        return estadoActual;
    }
    
    public String jugar(String pal){
        String reporte;
        if(enJuego){
            if(palSecreta.igual(pal)){
                reporte = "Ganaste ";
            }else{
                reporte = "Perdiste ";
            }
            reporte = reporteFinal(reporte);
        }else{
            reporte = "Inicializa el juego";
        }
        return reporte;
    }
    
    private String dibujarCuerpo(){
        String cuerpo;
        cuerpo = "";
        switch(nroErrores){
            case 6: cuerpo = "\\";
            case 5: cuerpo = "\n/ " + cuerpo;
            case 4: cuerpo = "\\" + cuerpo;
            case 3: cuerpo = "|" + cuerpo;
            case 2: cuerpo = "\n/" + cuerpo;
            case 1: cuerpo = " O " + cuerpo;
        }
        return cuerpo + "\n"; 
    }
}


/**
 * Write a description of class Palabra here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Palabra
{
    private String concepto;
    private String descripcion;
    private char[] letras;
    
    public Palabra(String concepto, String descripcion){
        this.concepto    = concepto.toUpperCase();
        this.descripcion = descripcion;
        letras           = new char[concepto.length()];
        inicializar();
    }
    
    public void inicializar(){
        for(int pos = 0; pos < letras.length; pos++){
            letras[pos] = '_';
        }
    }
    
    public boolean existe(char letra){
        boolean existe;
        letra  = toUpperCase(letra);
        existe = false;
        for(int ind = 0; ind < concepto.length(); ind++){
            if(concepto.charAt(ind) == letra){
                existe      = true;
                letras[ind] = letra;
            }
        }
        return existe;
    }
    
    private char toUpperCase(char letra){
        if(letra >= 97 && letra <= 122){
            letra = (char)(letra - 32);
        }
        return letra;
    }
    
    public boolean igual(String pal){
        return concepto.equals(pal.toUpperCase());
    }
    
    public String mostrarLetras(){
        String reporteLetras;
        reporteLetras = "";
        for(int pos = 0; pos < letras.length; pos++){
            reporteLetras = reporteLetras + letras[pos] + " "; 
        }
        return reporteLetras;
    }
    
    public boolean completa(){
        boolean completa;
        int pos;
        completa = true;
        pos = 0;
        while(pos < letras.length && completa){
            if(letras[pos] == '_'){
                completa = false;
            }
            pos++;
        }
        return completa;
    }
    
    public String getConcepto(){
        return concepto;
    }
    
    public String getDescripcion(){
        return descripcion;
    }
}

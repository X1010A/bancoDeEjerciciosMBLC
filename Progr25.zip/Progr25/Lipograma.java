import java.util.ArrayList;
/**
 * Write a description of class Lipograma here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Lipograma
{
    private char              letra;
    private ArrayList<String> palabras;
    
    public Lipograma(){
        letra = ' ';
        palabras = new ArrayList<String>();
    }
    
    public Lipograma(char letra){
        this.letra = letra;
        palabras = new ArrayList<String>();
    }
    
    public int getTamanio(){
        return palabras.size();
    }
    
    public String getLipograma(){
        String lipograma = "";
        for(String pal: palabras){
            lipograma = lipograma + pal + " ";
        }
        return lipograma.trim();
    }
    
    public void insertar(String pal){
        palabras.add(pal);
    }
}

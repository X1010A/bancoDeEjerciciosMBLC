
/**
 * Write a description of class Verificador here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Verificador
{
    private Lipograma[] lipogramas;
    
    public boolean esLipograma(String texto){
        String lipograma;
        
        lipograma = obtenerLipograma(texto);
        return lipograma.equals(texto);
    }
    public String  quitar(char v, String texto){
        String lipograma;
        String vocal = v +"";
        vocal = vocal.toLowerCase();
        v = vocal.charAt(0);
        lipograma = "";
        obtenerLipograma(texto);
        
        switch(v){
            case 'a':
            case 'á': lipograma = lipogramas[0].getLipograma(); break;
            case 'e':
            case 'é': lipograma = lipogramas[1].getLipograma(); break;    
            case 'i':
            case 'í': 
            case 'y': lipograma = lipogramas[2].getLipograma(); break;    
            case 'o':
            case 'ó': lipograma = lipogramas[3].getLipograma(); break;    
            case 'u':
            case 'ú': lipograma = lipogramas[4].getLipograma(); break;
        }
        return lipograma;
    }
    public String obtenerLipograma(String texto){
        String lipograma;
        String[] pals;
        Lipograma lipo; // es el lipograma mas grande
        
        // obtener pals
        pals = obtenerPalabras(texto);
        
        // distribuir las palabras de pals en los lipogramas/colecciones
        iniciarLipogramas();
        for(String pal: pals){
            ubicar(pal);
        }
        
        // identificar el lipograma mas grande en lipo
        lipo = new Lipograma();
        for(Lipograma l: lipogramas){
            if(l.getTamanio() > lipo.getTamanio()){
                lipo = l;
            }
        }
        
        // formar el lipograma desde lipo
        lipograma = lipo.getLipograma();
        return lipograma;
    }
    
    private void ubicar(String palabra){
        int pos;
        String palabraMod;
        char v;
        boolean cumple;
        palabraMod = palabra.toLowerCase();
        pos = buscarPos1raVocal(palabraMod);
        if(pos > -1){
            v = palabraMod.charAt(pos);
            cumple = true;
            pos++;
            while(pos < palabraMod.length() && cumple){
                if(esVocal(palabraMod.charAt(pos)))
                   if(!esIgual(palabraMod.charAt(pos),v)){
                       cumple = false;
                   }
                
                pos++;
            }
            if(cumple) 
                poner(palabra, v);
        }
    }
    
    private void poner(String pal, char v){
        switch(v){
            case 'a':
            case 'á': lipogramas[0].insertar(pal); break;
            case 'e':
            case 'é': lipogramas[1].insertar(pal); break;    
            case 'i':
            case 'í': 
            case 'y': lipogramas[2].insertar(pal); break;    
            case 'o':
            case 'ó': lipogramas[3].insertar(pal); break;    
            case 'u':
            case 'ú': lipogramas[4].insertar(pal); break;
        }
    }
    private boolean esIgual(char c1, char v){
        boolean esIgual;
        esIgual = false;
        switch(v){
            case 'a':
            case 'á': esIgual = c1 == 'a' || c1 == 'á' || c1 == 'y'; break;
            case 'e':
            case 'é': esIgual = c1 == 'e' || c1 == 'é' || c1 == 'y'; break;    
            case 'i':
            case 'í': 
            case 'y': esIgual = c1 == 'i' || c1 == 'í' || c1 == 'y'; break;    
            case 'o':
            case 'ó': esIgual = c1 == 'o' || c1 == 'ó' || c1 == 'y'; break;    
            case 'u':
            case 'ú': esIgual = c1 == 'u' || c1 == 'ú' || c1 == 'y'; break;    
        }
        return esIgual;
    }
    
    private int buscarPos1raVocal(String pal){
        int pos = -1;
        int i;
        i = 0;
        while(i<pal.length() && pos == -1){
            if(esVocal(pal.charAt(i)))
                pos = i;
            i++;    
        }
        return pos;
    }
    
    private boolean esVocal(char c){
        return c == 'a' || c == 'á' ||
               c == 'e' || c == 'é' ||
               c == 'i' || c == 'í' || c == 'y' ||
               c == 'o' || c == 'ó' ||
               c == 'u' || c == 'ú';
    }
    
    private void iniciarLipogramas(){
        lipogramas = new Lipograma[5];
        lipogramas[0] = new Lipograma('a');
        lipogramas[1] = new Lipograma('e');
        lipogramas[2] = new Lipograma('i');
        lipogramas[3] = new Lipograma('o');
        lipogramas[4] = new Lipograma('u');
    }
    
    private String[] obtenerPalabras(String texto){
        return texto.split(" "); // divide la cadena en subcadenas separadas por espacio
                                 // devuelve las subcadenas en un arreglo de cadenas
    }
}

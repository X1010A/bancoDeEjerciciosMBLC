import java.util.ArrayList;
/**
 * Write a description of class Imagen here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Imagen
{
    private int[][] foto;
    private int[][] copia;
    private int m,n;
    
    public Imagen(int[][] foto){
        this.foto = foto;
        m = foto.length;
        n = foto[0].length; 
    }
    
    // inciso d
    public ArrayList<Coordenada> buscar(Depredador dep){
        ArrayList<Coordenada> coordenadas;
        int tamanio;
        coordenadas = new ArrayList<Coordenada>();
        obtenerCopia();
        tamanio = dep.getTamano();
        for(int i = 0; i < m - tamanio + 1; i++){
            for(int j = 0; j < n - tamanio + 1; j++){
                if(dep.huellaIgual(obtenerArea(i,j,tamanio))){
                    coordenadas.add(new Coordenada(i,j));
                    marcarArea(i, j, tamanio);
                }
            }
        }
        return coordenadas;
    }
    
    
    // marca el area donde se ha encontrado una huella
    private void marcarArea(int i, int j, int tamanio){
        for(int fil = 0; fil < tamanio; fil++){
            for(int col = 0; col < tamanio; col++){
                copia[i+fil][j+col] = -1;
            }
        }
    }
    // se genera una copia de la foto para ir marcando las areas 
    // en las que se encuentra una huella
    private void obtenerCopia(){
        copia = new int[m][n];
        for(int i = 0; i < foto.length; i ++){
            for(int j = 0; j < foto[0].length; j++){
                copia[i][j] = foto[i][j];
            }
        }
    }
    // se genera una subimagen del area copiada
    // que equivale al tamanio de una huella
    private int[][] obtenerArea(int i, int j, int tamanio){
        int[][] area = new int[tamanio][tamanio];
        for(int fil = 0; fil < tamanio; fil ++){
            for(int col = 0; col < tamanio; col++){
                area[fil][col] = copia[i+fil][j+col];
            }
        }
        return area;
    }
}

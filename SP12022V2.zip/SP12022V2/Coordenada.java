
/**
 * Write a description of class Coordenada here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Coordenada
{
    private int x, y;
    
    public Coordenada(int x, int y){
        this.x = x;
        this.y = y;
    }
    
    public String toString(){
        return "(" + x + ", " + y + ")";
    }
}

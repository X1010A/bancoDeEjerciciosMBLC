
/**
 * Write a description of class Llenador here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Llenador
{
    private int[][] matriz;
    private int m, n;
    
    
    public Llenador(int filas, int columnas){
        m = filas;
        n = columnas;
        matriz = new int[m][n];
    }
    
    /**
     * 1 2 3
     * 8 9 4
     * 7 6 5
     */
    public void llenar(){
        int i, c1, c2, f1, f2;
        int dato;
        i = 1;
        c1 = 0;
        f1 = 0;
        c2 = n-1;
        f2 = m-1;
        dato = 1;
        while(c1 <= c2 && f1 <= f2){
            dato = llenar(c1, c2, f1, f2, dato);
            c1 = i;
            f1 = i;
            c2 = n-1-i;
            f2 = m-1-i;
            i++;
        }
    }
    
    private int llenar(int c1, int c2, int f1, int f2, int dato){
        dato = derecha(f1, c1, c2-1,dato);
        dato = abajo(f1, f2-1,c2, dato);
        dato = izquierda(f2, c2, c1+1, dato);
        dato = arriba(f2, f1+1, c1, dato);
        return dato;
    }
    private int derecha(int f, int c1, int c2, int dato){
        for(int c = c1; c <= c2 ; c++){
            matriz[f][c] = dato;
            dato++;
        }
        return dato;
    }
    
    private int abajo(int f1, int f2, int c, int dato){
        for(int f = f1; f <= f2 ; f++){
            matriz[f][c] = dato;
            dato++;
        }
        return dato;
    }
    
    private int izquierda(int f, int c1, int c2, int dato){
        for(int c = c1; c >= c2 ; c--){
            matriz[f][c] = dato;
            dato++;
        }
        return dato;
    }
    
    private int arriba(int f1, int f2, int c, int dato){
        for(int f = f1; f >= f2 ; f--){
            matriz[f][c] = dato;
            dato++;
        }
        return dato;
    }
    
    public String mostrar(){
        String reporte;
        reporte = "";
        for(int f = 0; f < m; f++){
            for(int c = 0; c < n; c++){
                reporte = reporte + matriz[f][c] + "\t"; 
            }
            reporte = reporte + "\n";
        }
        return reporte;
    }
}

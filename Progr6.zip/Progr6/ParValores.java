
/**
 * Write a description of class ParValores here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ParValores
{
    private double valor1;
    private double valor2;
    public ParValores(double valor1, double valor2){
        this.valor1 = valor1;
        this.valor2 = valor2;
    }
}

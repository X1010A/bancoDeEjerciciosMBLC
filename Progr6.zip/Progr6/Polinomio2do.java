
/**
 * Write a description of class Polinomio2do here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Polinomio2do
{
    private double a;
    private double b;
    private double c;
    public Polinomio2do(double a, double b, double c){
        this.a = a;
        this.b = b;
        this.c = c;
    }
    
    public String mostrar(){
        //ax^2 + bx + c = 0
        return a + "x^2 + " + b + "x + " + c ;
    }
    
    /**
     * calcularRaices
     * (x1,x2) el resultado es un par de valores reales
     */
    public ParValores calcularRaices(){
        ParValores raices;
        double x1, x2;
        double discr;
        
        //x1 = 0;
        //x2 = 0;
        
        if(a == 0){
            x1 = - c/b;
            x2 = x1;
        }else{
            discr = b*b - 4*a*c;
            if(discr < 0){
                x1 = 0;
                x2 = 0;
            }else{
                x1 = (-b + Math.sqrt(discr))/(2*a);
                x2 = (-b - Math.sqrt(discr))/(2*a);
            }
        }
        
        raices = new ParValores(x1, x2);
        return raices;
    }
}

     
     
     

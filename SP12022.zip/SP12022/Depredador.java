
/**
 * Write a description of class Depredador here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Depredador
{
    private String nombre;
    private int[][] huellaN;
    private int[][] huellaE;
    private int[][] huellaS;
    private int[][] huellaO;
    private int tamanio;
    // la huella siempre es cuadrada
    public Depredador(String nombre, int[][] huella){
        this.nombre = nombre;
        huellaN = huella;
        tamanio = huella.length;
        
        huellaE = rotar(huellaN);
        huellaS = rotar(huellaE);
        huellaO = rotar(huellaS);
    }
    // inciso e).
    private int[][] rotar(int[][] huella){
        int[][] huellaRotada;
        int colRotada, filRotada;
        int n = huella.length;
        huellaRotada = new int[n][n];
        for(int col = 0; col < n; col++){
            for(int fil = 0; fil < n; fil++){
                huellaRotada[fil][col] = huella[n-1-col][fil];
            }
            
        }
        return huellaRotada;
    }
    
    public int[][] getHuella(){
        return huellaN;
    }
    
    public int[][] getHuellaN(){
        return huellaN;
    }
    
    public int[][] getHuellaE(){
        return huellaE;
    }
    
    public int[][] getHuellaS(){
        return huellaS;
    }
    
    public int[][] getHuellaO(){
        return huellaO;
    }
    
}

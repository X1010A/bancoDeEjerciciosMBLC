

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
/**
 * The test class ImagenTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class ImagenTest
{
    Imagen imagen;
    /**
     * Default constructor for test class ImagenTest
     */
    public ImagenTest()
    {
    }

    /**
     * Sets up the test fixture.
     *
     * Called before every test case method.
     */
    @BeforeEach
    public void setUp()
    {    
    }

    /**
     * Tears down the test fixture.
     *
     * Called after every test case method.
     */
    @AfterEach
    public void tearDown()
    {
    }
    
    @Test
    public void test1(){
        imagen = new Imagen(new int[][]{{1,1,1,1,0,0,0,1,0,1,0},
                                        {1,1,1,1,0,0,0,1,0,1,0},
                                        {1,1,1,1,0,0,0,1,0,1,0},
                                        {1,1,1,1,0,0,0,1,0,1,0},
                                        {1,1,1,1,0,0,0,1,0,1,0},
                                        {1,1,1,1,0,0,0,1,0,1,0},
                                        {1,1,1,1,0,0,0,1,0,1,0},
                                        {1,1,1,1,0,0,0,1,0,1,0},
                                        {1,1,1,1,0,0,0,1,0,1,0},
                                        {1,1,1,1,0,0,0,1,0,1,0},
                                        {1,1,1,1,0,0,0,1,0,1,0}});
        Depredador dep;
        ArrayList<Coordenada> coord;
        dep = new Depredador("lia", new int[][]{{1,1,0},{1,1,0},{1,1,0}});
        coord = imagen.buscar(dep);
        System.out.println(coord.toString());
        dep = new Depredador("lia", new int[][]{{0,1,0},{0,1,0},{0,1,0}});
        coord = imagen.buscar(dep);
        System.out.println(coord.toString());
        dep = new Depredador("lia", new int[][]{{0,1,0},{0,1,1},{1,1,0}});
        coord = imagen.buscar(dep);
        System.out.println(coord.toString());
    }
    
    @Test
    public void test2(){
        imagen = new Imagen(new int[][]{{0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0},
                                        {0,0,0,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0},
                                        {0,0,0,1,0,0,0,0,0,0,0,0,0,0,1,0,0,0},
                                        {0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0},
                                        {0,0,1,1,0,0,0,0,0,1,1,0,0,0,1,0,0,0},
                                        {0,0,0,0,0,0,0,0,1,1,0,0,0,0,1,1,0,0},
                                        {0,0,0,0,0,0,0,0,0,1,0,0,0,1,1,0,0,0},
                                        {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                                        {0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0},
                                        {0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,0},
                                        {1,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0},
                                        {0,1,0,0,0,0,0,0,0,1,0,0,0,0,1,0,0,0},
                                        {0,0,1,0,0,0,0,0,1,0,0,0,0,1,1,1,0,0},
                                        {0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,0},
                                        {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},
                                        {0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,1,0,0},
                                        {0,0,0,0,1,1,1,0,0,0,1,0,0,0,0,0,1,0},
                                        {0,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,0,1}});
        Depredador dep;
        ArrayList<Coordenada> coord;
        dep = new Depredador("lia", new int[][]{{1,0,0},{0,1,0},{0,0,1}});
        coord = imagen.buscarTodas(dep);
        System.out.println(coord.toString());
        dep = new Depredador("lia", new int[][]{{0,1,1},{0,1,0},{1,1,0}});
        coord = imagen.buscarTodas(dep);
        System.out.println(coord.toString());
        dep = new Depredador("lia", new int[][]{{0,1,0},{0,1,1},{1,1,0}});
        coord = imagen.buscarTodas(dep);
        System.out.println(coord.toString());
    }
}

import java.util.ArrayList;
/**
 * Write a description of class Imagen here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Imagen
{
    private int[][] foto;
    private int[][] copia;
    private int m,n;
    
    public Imagen(int[][] foto){
        this.foto = foto;
        m = foto.length;
        n = foto[0].length; 
    }
    
    // inciso d
    public ArrayList<Coordenada> buscar(Depredador dep){
        ArrayList<Coordenada> coordenadas;
        coordenadas = new ArrayList<Coordenada>();
        obtenerCopia();
        buscar(dep.getHuella(), coordenadas);
        return coordenadas;
    }
    
    private void buscar(int[][] huella, ArrayList<Coordenada> coordenadas){    
        
        for(int i = 0; i < m - huella.length + 1; i++){
            for(int j = 0; j < n - huella[0].length + 1; j++){
                if(existe(i,j,huella)){
                    coordenadas.add(new Coordenada(i,j));
                }
            }
        }
    }
    
    // inciso f
    public ArrayList<Coordenada> buscarTodas(Depredador dep){
        ArrayList<Coordenada> coordenadas;
        coordenadas = new ArrayList<Coordenada>();
        obtenerCopia();
        
        buscar(dep.getHuellaN(), coordenadas);
        buscar(dep.getHuellaE(), coordenadas);
        buscar(dep.getHuellaS(), coordenadas);
        buscar(dep.getHuellaO(), coordenadas);
                
        return coordenadas;
    }
    
    //verifica si desde la posicion i, j  existe la huella
    // en caso de que existe esa area es marcada para ya no buscar alli
    private boolean existe(int i, int j, int[][] huella){
        boolean existe;
        int fil, col;
        existe = true;
        fil = 0;
        col = 0;
        
        while(fil < huella.length && existe){
            if(col < huella[0].length){
                if(copia[i+fil][j+col] != huella[fil][col]){
                    existe = false;
                }
                col++;
            }else{
                fil++;
                col = 0;
            }
        }
        if(existe){
            marcarArea(i, j, huella);
        }
        return existe;
    }
    
    // marca el area donde se ha encontrado una huella
    private void marcarArea(int i, int j, int[][] huella){
        for(int fil = 0; fil < huella.length; fil++){
            for(int col = 0; col < huella[0].length; col++){
                copia[i+fil][j+col] = -1;
            }
        }
    }
    // se genera una copia de la foto para ir marzando las areas 
    // en las que se encuentra una huella
    private void obtenerCopia(){
        copia = new int[m][n];
        for(int i = 0; i < foto.length; i ++){
            for(int j = 0; j < foto[0].length; j++){
                copia[i][j] = foto[i][j];
            }
        }
    }
}
